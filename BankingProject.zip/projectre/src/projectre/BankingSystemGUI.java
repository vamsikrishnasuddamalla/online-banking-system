package projectre;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

class BankAccount {
    private int accountNumber;
    private String accountHolder;
    private double balance;

    public BankAccount(int accountNumber, String accountHolder, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true; // Withdrawal successful
        }
        return false; // Withdrawal failed
    }
}

class Bank {
	 private List<BankAccount> accounts;

	    public Bank() {
	        accounts = new ArrayList<>();
	    }

	    public void addAccount(BankAccount account) {
	        accounts.add(account);
	    }

	    public BankAccount getAccount(int accountNumber) {
	        for (BankAccount account : accounts) {
	            if (account.getAccountNumber() == accountNumber) {
	                return account;
	            }
	        }
	        return null; // Account not found
	    }

	    public List<BankAccount> getAllAccounts() {
	        return accounts;
	    }
}

public class BankingSystemGUI implements ActionListener {
    private JFrame frame;
    private JTextArea textArea;
    private JTextField accountNumberField;
    private JTextField accountHolderField;
    private JTextField initialBalanceField;
    private JTextField transactionAmountField;

    private Bank bank;

    public BankingSystemGUI() {
        frame = new JFrame("Banking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        bank = new Bank();

        textArea = new JTextArea(20, 40);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        JPanel panel = new JPanel(new GridBagLayout());

        JLabel accountNumberLabel = new JLabel("Account Number:");
        JLabel accountHolderLabel = new JLabel("Account Holder:");
        JLabel initialBalanceLabel = new JLabel("Initial Balance:");
        JLabel transactionAmountLabel = new JLabel("Transaction Amount:");

        accountNumberField = new JTextField(10);
        accountHolderField = new JTextField(20);
        initialBalanceField = new JTextField(10);
        transactionAmountField = new JTextField(10);

        JButton createAccountButton = new JButton("Create Account");
        JButton depositButton = new JButton("Deposit");
        JButton withdrawButton = new JButton("Withdraw");
        JButton checkBalanceButton = new JButton("Check Balance");
        JButton listAccountsButton = new JButton("List Accounts");

        createAccountButton.addActionListener(this);
        depositButton.addActionListener(this);
        withdrawButton.addActionListener(this);
        checkBalanceButton.addActionListener(this);
        listAccountsButton.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(accountNumberLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(accountNumberField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(accountHolderLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(accountHolderField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(initialBalanceLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(initialBalanceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(createAccountButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(transactionAmountLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(transactionAmountField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(depositButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(withdrawButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(checkBalanceButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 8;
        panel.add(listAccountsButton, gbc);

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(panel, BorderLayout.WEST);
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        if ("Create Account".equals(actionCommand)) {
            createAccount();
        } else if ("Deposit".equals(actionCommand)) {
            deposit();
        } else if ("Withdraw".equals(actionCommand)) {
            withdraw();
        } else if ("Check Balance".equals(actionCommand)) {
            checkBalance();
        } else if ("List Accounts".equals(actionCommand)) {
            listAccounts();
        }
    }

    private void createAccount() {
        try {
            int accountNumber = Integer.parseInt(accountNumberField.getText());
            String accountHolder = accountHolderField.getText();
            double initialBalance = Double.parseDouble(initialBalanceField.getText());

            BankAccount account = new BankAccount(accountNumber, accountHolder, initialBalance);
            bank.addAccount(account);

            textArea.append("Account created successfully.\n");
            clearInputFields();
        } catch (NumberFormatException ex) {
            textArea.append("Invalid input. Please enter valid values.\n");
        }
    }

    private void deposit() {
        try {
            int accountNumber = Integer.parseInt(accountNumberField.getText());
            double depositAmount = Double.parseDouble(transactionAmountField.getText());

            BankAccount account = bank.getAccount(accountNumber);
            if (account != null) {
                account.deposit(depositAmount);
                textArea.append("Deposited $" + depositAmount + " into Account #" + accountNumber + ".\n");
                clearInputFields();
            } else {
                textArea.append("Account not found.\n");
            }
        } catch (NumberFormatException ex) {
            textArea.append("Invalid input for account number or deposit amount. Please enter valid values.\n");
        }
    }

    private void withdraw() {
        try {
            int accountNumber = Integer.parseInt(accountNumberField.getText());
            double withdrawalAmount = Double.parseDouble(transactionAmountField.getText());

            BankAccount account = bank.getAccount(accountNumber);
            if (account != null) {
                if (account.withdraw(withdrawalAmount)) {
                    textArea.append("Withdrawn $" + withdrawalAmount + " from Account #" + accountNumber + ".\n");
                } else {
                    textArea.append("Insufficient funds or invalid withdrawal amount.\n");
                }
                clearInputFields();
            } else {
                textArea.append("Account not found.\n");
            }
        } catch (NumberFormatException ex) {
            textArea.append("Invalid input for account number or withdrawal amount. Please enter valid values.\n");
        }
    }


    private void checkBalance() {
        try {
            int accountNumber = Integer.parseInt(accountNumberField.getText());

            BankAccount account = bank.getAccount(accountNumber);
            if (account != null) {
                textArea.append("Account #" + accountNumber + " balance: $" + account.getBalance() + "\n");
                clearInputFields();
            } else {
                textArea.append("Account not found.\n");
            }
        } catch (NumberFormatException ex) {
            textArea.append("Invalid input. Please enter valid values.\n");
        }
    }

    private void listAccounts() {
        List<BankAccount> accounts = bank.getAllAccounts();
        if (accounts.isEmpty()) {
            textArea.append("No accounts found.\n");
        } else {
            textArea.append("List of Account Holders:\n");
            for (BankAccount account : accounts) {
                textArea.append("Account #" + account.getAccountNumber() + ": " + account.getAccountHolder() + "\n");
            }
        }
    }

    private void clearInputFields() {
        accountNumberField.setText("");
        accountHolderField.setText("");
        initialBalanceField.setText("");
        transactionAmountField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BankingSystemGUI();
            }
        });
    }
}
