/**
 * 
 */
/**
 * @author lenovo
 *
 */
module projectre {
	requires java.desktop;
}